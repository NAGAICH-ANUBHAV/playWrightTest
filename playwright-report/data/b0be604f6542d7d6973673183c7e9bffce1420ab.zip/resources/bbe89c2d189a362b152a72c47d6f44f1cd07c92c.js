try{let e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},t=(new e.Error).stack;t&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[t]="70d90a96-7e26-4347-9cf0-c610a5bc376c",e._sentryDebugIdIdentifier="sentry-dbid-70d90a96-7e26-4347-9cf0-c610a5bc376c")}catch(e){}"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[129],{69579:function(e,t,n){n.d(t,{U0:function(){return eZ},gS:function(){return eY},rp:function(){return F}});var r=n(33975);let o=r.n2o,i=o.document,a=o.navigator,s="Report a Bug",l="Cancel",u="Send Bug Report",c="Confirm",d="Report a Bug",_="your.email@example.org",f="Email",h="What's the bug? What did you expect?",p="Description",g="Your Name",m="Name",b="Thank you for your report!",v="(required)",y="Add a screenshot",w="Remove screenshot",x=(e,t={includeReplay:!0})=>{if(!e.message)throw Error("Unable to submit feedback with empty message");let n=(0,r.s3S)();if(!n)throw Error("No client setup, cannot send feedback.");e.tags&&Object.keys(e.tags).length&&(0,r.nZL)().setTags(e.tags);let o=(0,r.N$K)({source:"api",url:(0,r.l4O)(),...e},t);return new Promise((e,t)=>{let r=setTimeout(()=>t("Unable to determine if Feedback was correctly sent."),5e3),i=n.on("afterSendEvent",(n,a)=>n.event_id!==o?void 0:(clearTimeout(r),i(),a&&"number"==typeof a.statusCode&&a.statusCode>=200&&a.statusCode<300)?e(o):a&&"number"==typeof a.statusCode&&0===a.statusCode?t("Unable to send Feedback. This is because of network issues, or because you are using an ad-blocker."):a&&"number"==typeof a.statusCode&&403===a.statusCode?t("Unable to send Feedback. This could be because this domain is not in your list of allowed domains."):t("Unable to send Feedback. This could be because of network issues, or because you are using an ad-blocker"))})},C="undefined"==typeof __SENTRY_DEBUG__||__SENTRY_DEBUG__;function k(e,t){return{...e,...t,tags:{...e.tags,...t.tags},onFormOpen:()=>{t.onFormOpen?.(),e.onFormOpen?.()},onFormClose:()=>{t.onFormClose?.(),e.onFormClose?.()},onSubmitSuccess:n=>{t.onSubmitSuccess?.(n),e.onSubmitSuccess?.(n)},onSubmitError:n=>{t.onSubmitError?.(n),e.onSubmitError?.(n)},onFormSubmitted:()=>{t.onFormSubmitted?.(),e.onFormSubmitted?.()},themeDark:{...e.themeDark,...t.themeDark},themeLight:{...e.themeLight,...t.themeLight}}}function S(e,t){return Object.entries(t).forEach(([t,n])=>{e.setAttributeNS(null,t,n)}),e}let M="rgba(88, 74, 192, 1)",L={foreground:"#2b2233",background:"#ffffff",accentForeground:"white",accentBackground:M,successColor:"#268d75",errorColor:"#df3338",border:"1.5px solid rgba(41, 35, 47, 0.13)",boxShadow:"0px 4px 24px 0px rgba(43, 34, 51, 0.12)",outline:"1px auto var(--accent-background)",interactiveFilter:"brightness(95%)"},E={foreground:"#ebe6ef",background:"#29232f",accentForeground:"white",accentBackground:M,successColor:"#2da98c",errorColor:"#f55459",border:"1.5px solid rgba(235, 230, 239, 0.15)",boxShadow:"0px 4px 24px 0px rgba(43, 34, 51, 0.12)",outline:"1px auto var(--accent-background)",interactiveFilter:"brightness(150%)"};function D(e){return`
  --foreground: ${e.foreground};
  --background: ${e.background};
  --accent-foreground: ${e.accentForeground};
  --accent-background: ${e.accentBackground};
  --success-color: ${e.successColor};
  --error-color: ${e.errorColor};
  --border: ${e.border};
  --box-shadow: ${e.boxShadow};
  --outline: ${e.outline};
  --interactive-filter: ${e.interactiveFilter};
  `}let F=({lazyLoadIntegration:e,getModalIntegration:t,getScreenshotIntegration:n})=>({id:M="sentry-feedback",autoInject:F=!0,showBranding:H=!0,isEmailRequired:T=!1,isNameRequired:R=!1,showEmail:P=!0,showName:A=!0,enableScreenshot:W=!0,useSentryUser:I={email:"email",name:"username"},_experiments:B={},tags:N,styleNonce:O,scriptNonce:U,colorScheme:z="system",themeLight:X={},themeDark:Y={},addScreenshotButtonLabel:$=y,cancelButtonLabel:j=l,confirmButtonLabel:q=c,emailLabel:V=f,emailPlaceholder:G=_,formTitle:Z=d,isRequiredLabel:K=v,messageLabel:Q=p,messagePlaceholder:J=h,nameLabel:ee=m,namePlaceholder:et=g,removeScreenshotButtonLabel:en=w,submitButtonLabel:er=u,successMessageText:eo=b,triggerLabel:ei=s,triggerAriaLabel:ea="",onFormOpen:es,onFormClose:el,onSubmitSuccess:eu,onSubmitError:ec,onFormSubmitted:ed}={})=>{let e_={id:M,autoInject:F,showBranding:H,isEmailRequired:T,isNameRequired:R,showEmail:P,showName:A,enableScreenshot:W,useSentryUser:I,tags:N,styleNonce:O,scriptNonce:U,colorScheme:z,themeDark:Y,themeLight:X,triggerLabel:ei,triggerAriaLabel:ea,cancelButtonLabel:j,submitButtonLabel:er,confirmButtonLabel:q,formTitle:Z,emailLabel:V,emailPlaceholder:G,messageLabel:Q,messagePlaceholder:J,nameLabel:ee,namePlaceholder:et,successMessageText:eo,isRequiredLabel:K,addScreenshotButtonLabel:$,removeScreenshotButtonLabel:en,onFormClose:el,onFormOpen:es,onSubmitError:ec,onSubmitSuccess:eu,onFormSubmitted:ed,_experiments:B},ef=null,eh=[],ep=e=>{if(!ef){let t=i.createElement("div");t.id=String(e.id),i.body.appendChild(t),(ef=t.attachShadow({mode:"open"})).appendChild(function({colorScheme:e,themeDark:t,themeLight:n,styleNonce:r}){let o=i.createElement("style");return o.textContent=`
:host {
  --font-family: system-ui, 'Helvetica Neue', Arial, sans-serif;
  --font-size: 14px;
  --z-index: 100000;

  --page-margin: 16px;
  --inset: auto 0 0 auto;
  --actor-inset: var(--inset);

  font-family: var(--font-family);
  font-size: var(--font-size);

  ${"system"!==e?"color-scheme: only light;":""}

  ${D("dark"===e?{...E,...t}:{...L,...n})}
}

${"system"===e?`
@media (prefers-color-scheme: dark) {
  :host {
    ${D({...E,...t})}
  }
}`:""}
}
`,r&&o.setAttribute("nonce",r),o}(e))}return ef},eg=async o=>{let i,s;let l=o.enableScreenshot&&!(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(a.userAgent)||/Macintosh/i.test(a.userAgent)&&a.maxTouchPoints&&a.maxTouchPoints>1)&&!!isSecureContext;try{i=(t?t():await e("feedbackModalIntegration",U))(),(0,r.M5N)(i)}catch{throw C&&r.kgX.error("[Feedback] Error when trying to load feedback integrations. Try using `feedbackSyncIntegration` in your `Sentry.init`."),Error("[Feedback] Missing feedback modal integration!")}try{let t=l?n?n():await e("feedbackScreenshotIntegration",U):void 0;t&&(s=t(),(0,r.M5N)(s))}catch{C&&r.kgX.error("[Feedback] Missing feedback screenshot integration. Proceeding without screenshots.")}let u=i.createDialog({options:{...o,onFormClose:()=>{u?.close(),o.onFormClose?.()},onFormSubmitted:()=>{u?.close(),o.onFormSubmitted?.()}},screenshotIntegration:s,sendFeedback:x,shadow:ep(o)});return u},em=(e,t={})=>{let n=k(e_,t),o="string"==typeof e?i.querySelector(e):"function"==typeof e.addEventListener?e:null;if(!o)throw C&&r.kgX.error("[Feedback] Unable to attach to target element"),Error("Unable to attach to target element");let a=null,s=async()=>{a||(a=await eg({...n,onFormSubmitted:()=>{a?.removeFromDom(),n.onFormSubmitted?.()}})),a.appendToDom(),a.open()};o.addEventListener("click",s);let l=()=>{eh=eh.filter(e=>e!==l),a?.removeFromDom(),a=null,o.removeEventListener("click",s)};return eh.push(l),l},eb=(e={})=>{let t=k(e_,e),n=ep(t),r=function({triggerLabel:e,triggerAriaLabel:t,shadow:n,styleNonce:r}){let a=i.createElement("button");if(a.type="button",a.className="widget__actor",a.ariaHidden="false",a.ariaLabel=t||e||s,a.appendChild(function(){let e=e=>o.document.createElementNS("http://www.w3.org/2000/svg",e),t=S(e("svg"),{width:"20",height:"20",viewBox:"0 0 20 20",fill:"var(--actor-color, var(--foreground))"}),n=S(e("g"),{clipPath:"url(#clip0_57_80)"}),r=S(e("path"),{"fill-rule":"evenodd","clip-rule":"evenodd",d:"M15.6622 15H12.3997C12.2129 14.9959 12.031 14.9396 11.8747 14.8375L8.04965 12.2H7.49956V19.1C7.4875 19.3348 7.3888 19.5568 7.22256 19.723C7.05632 19.8892 6.83435 19.9879 6.59956 20H2.04956C1.80193 19.9968 1.56535 19.8969 1.39023 19.7218C1.21511 19.5467 1.1153 19.3101 1.11206 19.0625V12.2H0.949652C0.824431 12.2017 0.700142 12.1783 0.584123 12.1311C0.468104 12.084 0.362708 12.014 0.274155 11.9255C0.185602 11.8369 0.115689 11.7315 0.0685419 11.6155C0.0213952 11.4995 -0.00202913 11.3752 -0.00034808 11.25V3.75C-0.00900498 3.62067 0.0092504 3.49095 0.0532651 3.36904C0.0972798 3.24712 0.166097 3.13566 0.255372 3.04168C0.344646 2.94771 0.452437 2.87327 0.571937 2.82307C0.691437 2.77286 0.82005 2.74798 0.949652 2.75H8.04965L11.8747 0.1625C12.031 0.0603649 12.2129 0.00407221 12.3997 0H15.6622C15.9098 0.00323746 16.1464 0.103049 16.3215 0.278167C16.4966 0.453286 16.5964 0.689866 16.5997 0.9375V3.25269C17.3969 3.42959 18.1345 3.83026 18.7211 4.41679C19.5322 5.22788 19.9878 6.32796 19.9878 7.47502C19.9878 8.62209 19.5322 9.72217 18.7211 10.5333C18.1345 11.1198 17.3969 11.5205 16.5997 11.6974V14.0125C16.6047 14.1393 16.5842 14.2659 16.5395 14.3847C16.4948 14.5035 16.4268 14.6121 16.3394 14.7042C16.252 14.7962 16.147 14.8698 16.0307 14.9206C15.9144 14.9714 15.7891 14.9984 15.6622 15ZM1.89695 10.325H1.88715V4.625H8.33715C8.52423 4.62301 8.70666 4.56654 8.86215 4.4625L12.6872 1.875H14.7247V13.125H12.6872L8.86215 10.4875C8.70666 10.3835 8.52423 10.327 8.33715 10.325H2.20217C2.15205 10.3167 2.10102 10.3125 2.04956 10.3125C1.9981 10.3125 1.94708 10.3167 1.89695 10.325ZM2.98706 12.2V18.1625H5.66206V12.2H2.98706ZM16.5997 9.93612V5.01393C16.6536 5.02355 16.7072 5.03495 16.7605 5.04814C17.1202 5.13709 17.4556 5.30487 17.7425 5.53934C18.0293 5.77381 18.2605 6.06912 18.4192 6.40389C18.578 6.73866 18.6603 7.10452 18.6603 7.47502C18.6603 7.84552 18.578 8.21139 18.4192 8.54616C18.2605 8.88093 18.0293 9.17624 17.7425 9.41071C17.4556 9.64518 17.1202 9.81296 16.7605 9.90191C16.7072 9.91509 16.6536 9.9265 16.5997 9.93612Z"});t.appendChild(n).appendChild(r);let i=e("defs"),a=S(e("clipPath"),{id:"clip0_57_80"}),s=S(e("rect"),{width:"20",height:"20",fill:"white"});return a.appendChild(s),i.appendChild(a),t.appendChild(i).appendChild(a).appendChild(s),t}()),e){let t=i.createElement("span");t.appendChild(i.createTextNode(e)),a.appendChild(t)}let l=function(e){let t=i.createElement("style");return t.textContent=`
.widget__actor {
  position: fixed;
  z-index: var(--z-index);
  margin: var(--page-margin);
  inset: var(--actor-inset);

  display: flex;
  align-items: center;
  gap: 8px;
  padding: 16px;

  font-family: inherit;
  font-size: var(--font-size);
  font-weight: 600;
  line-height: 1.14em;
  text-decoration: none;

  background: var(--actor-background, var(--background));
  border-radius: var(--actor-border-radius, 1.7em/50%);
  border: var(--actor-border, var(--border));
  box-shadow: var(--actor-box-shadow, var(--box-shadow));
  color: var(--actor-color, var(--foreground));
  fill: var(--actor-color, var(--foreground));
  cursor: pointer;
  opacity: 1;
  transition: transform 0.2s ease-in-out;
  transform: translate(0, 0) scale(1);
}
.widget__actor[aria-hidden="true"] {
  opacity: 0;
  pointer-events: none;
  visibility: hidden;
  transform: translate(0, 16px) scale(0.98);
}

.widget__actor:hover {
  background: var(--actor-hover-background, var(--background));
  filter: var(--interactive-filter);
}

.widget__actor svg {
  width: 1.14em;
  height: 1.14em;
}

@media (max-width: 600px) {
  .widget__actor span {
    display: none;
  }
}
`,e&&t.setAttribute("nonce",e),t}(r);return{el:a,appendToDom(){n.appendChild(l),n.appendChild(a)},removeFromDom(){n.removeChild(a),n.removeChild(l)},show(){a.ariaHidden="false"},hide(){a.ariaHidden="true"}}}({triggerLabel:t.triggerLabel,triggerAriaLabel:t.triggerAriaLabel,shadow:n,styleNonce:O});return em(r.el,{...t,onFormOpen(){r.hide()},onFormClose(){r.show()},onFormSubmitted(){r.show()}}),r};return{name:"Feedback",setupOnce(){(0,r.jUY)()&&e_.autoInject&&("loading"===i.readyState?i.addEventListener("DOMContentLoaded",()=>eb().appendToDom()):eb().appendToDom())},attachTo:em,createWidget(e={}){let t=eb(k(e_,e));return t.appendToDom(),t},createForm:async(e={})=>eg(k(e_,e)),remove(){ef&&(ef.parentElement?.remove(),ef=null),eh.forEach(e=>e()),eh=[]}}};var H,T,R,P,A,W,I,B={},N=[],O=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,U=Array.isArray;function z(e,t){for(var n in t)e[n]=t[n];return e}function X(e){var t=e.parentNode;t&&t.removeChild(e)}function Y(e,t,n){var r,o,i,a={};for(i in t)"key"==i?r=t[i]:"ref"==i?o=t[i]:a[i]=t[i];if(arguments.length>2&&(a.children=arguments.length>3?H.call(arguments,2):n),"function"==typeof e&&null!=e.defaultProps)for(i in e.defaultProps)void 0===a[i]&&(a[i]=e.defaultProps[i]);return $(e,a,r,o,null)}function $(e,t,n,r,o){var i={type:e,props:t,key:n,ref:r,__k:null,__:null,__b:0,__e:null,__d:void 0,__c:null,constructor:void 0,__v:null==o?++R:o,__i:-1,__u:0};return null==o&&null!=T.vnode&&T.vnode(i),i}function j(e){return e.children}function q(e,t){this.props=e,this.context=t}function V(e,t){if(null==t)return e.__?V(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if(null!=(n=e.__k[t])&&null!=n.__e)return n.__e;return"function"==typeof e.type?V(e):null}function G(e){(!e.__d&&(e.__d=!0)&&P.push(e)&&!Z.__r++||A!==T.debounceRendering)&&((A=T.debounceRendering)||W)(Z)}function Z(){var e,t,n,r=[],o=[];for(P.sort(I);e=P.shift();)e.__d&&(n=P.length,t=function(e,t,n){var r,o=e.__v,i=o.__e,a=e.__P;if(a)return(r=z({},o)).__v=o.__v+1,T.vnode&&T.vnode(r),en(a,r,o,e.__n,void 0!==a.ownerSVGElement,32&o.__u?[i]:null,t,null==i?V(o):i,!!(32&o.__u),n),r.__.__k[r.__i]=r,r.__d=void 0,r.__e!=i&&function e(t){var n,r;if(null!=(t=t.__)&&null!=t.__c){for(t.__e=t.__c.base=null,n=0;n<t.__k.length;n++)if(null!=(r=t.__k[n])&&null!=r.__e){t.__e=t.__c.base=r.__e;break}return e(t)}}(r),r}(e,r,o)||t,0===n||P.length>n?(er(r,t,o),o.length=r.length=0,t=void 0,P.sort(I)):t&&T.__c&&T.__c(t,N));t&&er(r,t,o),Z.__r=0}function K(e,t,n,r,o,i,a,s,l,u,c){var d,_,f,h,p,g=r&&r.__k||N,m=t.length;for(n.__d=l,function(e,t,n){var r,o,i,a,s,l=t.length,u=n.length,c=u,d=0;for(e.__k=[],r=0;r<l;r++)null!=(o=e.__k[r]=null==(o=t[r])||"boolean"==typeof o||"function"==typeof o?null:"string"==typeof o||"number"==typeof o||"bigint"==typeof o||o.constructor==String?$(null,o,null,null,o):U(o)?$(j,{children:o},null,null,null):void 0===o.constructor&&o.__b>0?$(o.type,o.props,o.key,o.ref?o.ref:null,o.__v):o)?(o.__=e,o.__b=e.__b+1,s=function(e,t,n,r){var o=e.key,i=e.type,a=n-1,s=n+1,l=t[n];if(null===l||l&&o==l.key&&i===l.type)return n;if(r>(null!=l&&0==(131072&l.__u)?1:0))for(;a>=0||s<t.length;){if(a>=0){if((l=t[a])&&0==(131072&l.__u)&&o==l.key&&i===l.type)return a;a--}if(s<t.length){if((l=t[s])&&0==(131072&l.__u)&&o==l.key&&i===l.type)return s;s++}}return -1}(o,n,a=r+d,c),o.__i=s,i=null,-1!==s&&(c--,(i=n[s])&&(i.__u|=131072)),null==i||null===i.__v?(-1==s&&d--,"function"!=typeof o.type&&(o.__u|=65536)):s!==a&&(s===a+1?d++:s>a?c>l-a?d+=s-a:d--:d=s<a&&s==a-1?s-a:0,s!==r+d&&(o.__u|=65536))):(i=n[r])&&null==i.key&&i.__e&&(i.__e==e.__d&&(e.__d=V(i)),ei(i,i,!1),n[r]=null,c--);if(c)for(r=0;r<u;r++)null!=(i=n[r])&&0==(131072&i.__u)&&(i.__e==e.__d&&(e.__d=V(i)),ei(i,i))}(n,t,g),l=n.__d,d=0;d<m;d++)null!=(f=n.__k[d])&&"boolean"!=typeof f&&"function"!=typeof f&&(_=-1===f.__i?B:g[f.__i]||B,f.__i=d,en(e,f,_,o,i,a,s,l,u,c),h=f.__e,f.ref&&_.ref!=f.ref&&(_.ref&&eo(_.ref,null,f),c.push(f.ref,f.__c||h,f)),null==p&&null!=h&&(p=h),65536&f.__u||_.__k===f.__k?l=function e(t,n,r){var o,i;if("function"==typeof t.type){for(o=t.__k,i=0;o&&i<o.length;i++)o[i]&&(o[i].__=t,n=e(o[i],n,r));return n}t.__e!=n&&(r.insertBefore(t.__e,n||null),n=t.__e);do n=n&&n.nextSibling;while(null!=n&&8===n.nodeType);return n}(f,l,e):"function"==typeof f.type&&void 0!==f.__d?l=f.__d:h&&(l=h.nextSibling),f.__d=void 0,f.__u&=-196609);n.__d=l,n.__e=p}function Q(e,t,n){"-"===t[0]?e.setProperty(t,null==n?"":n):e[t]=null==n?"":"number"!=typeof n||O.test(t)?n:n+"px"}function J(e,t,n,r,o){var i;e:if("style"===t){if("string"==typeof n)e.style.cssText=n;else{if("string"==typeof r&&(e.style.cssText=r=""),r)for(t in r)n&&t in n||Q(e.style,t,"");if(n)for(t in n)r&&n[t]===r[t]||Q(e.style,t,n[t])}}else if("o"===t[0]&&"n"===t[1])i=t!==(t=t.replace(/(PointerCapture)$|Capture$/i,"$1")),t=t.toLowerCase() in e?t.toLowerCase().slice(2):t.slice(2),e.l||(e.l={}),e.l[t+i]=n,n?r?n.u=r.u:(n.u=Date.now(),e.addEventListener(t,i?et:ee,i)):e.removeEventListener(t,i?et:ee,i);else{if(o)t=t.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if("width"!==t&&"height"!==t&&"href"!==t&&"list"!==t&&"form"!==t&&"tabIndex"!==t&&"download"!==t&&"rowSpan"!==t&&"colSpan"!==t&&"role"!==t&&t in e)try{e[t]=null==n?"":n;break e}catch(e){}"function"==typeof n||(null==n||!1===n&&"-"!==t[4]?e.removeAttribute(t):e.setAttribute(t,n))}}function ee(e){if(this.l){var t=this.l[e.type+!1];if(e.t){if(e.t<=t.u)return}else e.t=Date.now();return t(T.event?T.event(e):e)}}function et(e){if(this.l)return this.l[e.type+!0](T.event?T.event(e):e)}function en(e,t,n,r,o,i,a,s,l,u){var c,d,_,f,h,p,g,m,b,v,y,w,x,C,k,S=t.type;if(void 0!==t.constructor)return null;128&n.__u&&(l=!!(32&n.__u),i=[s=t.__e=n.__e]),(c=T.__b)&&c(t);e:if("function"==typeof S)try{if(m=t.props,b=(c=S.contextType)&&r[c.__c],v=c?b?b.props.value:c.__:r,n.__c?g=(d=t.__c=n.__c).__=d.__E:("prototype"in S&&S.prototype.render?t.__c=d=new S(m,v):(t.__c=d=new q(m,v),d.constructor=S,d.render=ea),b&&b.sub(d),d.props=m,d.state||(d.state={}),d.context=v,d.__n=r,_=d.__d=!0,d.__h=[],d._sb=[]),null==d.__s&&(d.__s=d.state),null!=S.getDerivedStateFromProps&&(d.__s==d.state&&(d.__s=z({},d.__s)),z(d.__s,S.getDerivedStateFromProps(m,d.__s))),f=d.props,h=d.state,d.__v=t,_)null==S.getDerivedStateFromProps&&null!=d.componentWillMount&&d.componentWillMount(),null!=d.componentDidMount&&d.__h.push(d.componentDidMount);else{if(null==S.getDerivedStateFromProps&&m!==f&&null!=d.componentWillReceiveProps&&d.componentWillReceiveProps(m,v),!d.__e&&(null!=d.shouldComponentUpdate&&!1===d.shouldComponentUpdate(m,d.__s,v)||t.__v===n.__v)){for(t.__v!==n.__v&&(d.props=m,d.state=d.__s,d.__d=!1),t.__e=n.__e,t.__k=n.__k,t.__k.forEach(function(e){e&&(e.__=t)}),y=0;y<d._sb.length;y++)d.__h.push(d._sb[y]);d._sb=[],d.__h.length&&a.push(d);break e}null!=d.componentWillUpdate&&d.componentWillUpdate(m,d.__s,v),null!=d.componentDidUpdate&&d.__h.push(function(){d.componentDidUpdate(f,h,p)})}if(d.context=v,d.props=m,d.__P=e,d.__e=!1,w=T.__r,x=0,"prototype"in S&&S.prototype.render){for(d.state=d.__s,d.__d=!1,w&&w(t),c=d.render(d.props,d.state,d.context),C=0;C<d._sb.length;C++)d.__h.push(d._sb[C]);d._sb=[]}else do d.__d=!1,w&&w(t),c=d.render(d.props,d.state,d.context),d.state=d.__s;while(d.__d&&++x<25);d.state=d.__s,null!=d.getChildContext&&(r=z(z({},r),d.getChildContext())),_||null==d.getSnapshotBeforeUpdate||(p=d.getSnapshotBeforeUpdate(f,h)),K(e,U(k=null!=c&&c.type===j&&null==c.key?c.props.children:c)?k:[k],t,n,r,o,i,a,s,l,u),d.base=t.__e,t.__u&=-161,d.__h.length&&a.push(d),g&&(d.__E=d.__=null)}catch(e){t.__v=null,l||null!=i?(t.__e=s,t.__u|=l?160:32,i[i.indexOf(s)]=null):(t.__e=n.__e,t.__k=n.__k),T.__e(e,t,n)}else null==i&&t.__v===n.__v?(t.__k=n.__k,t.__e=n.__e):t.__e=function(e,t,n,r,o,i,a,s,l){var u,c,d,_,f,h,p,g=n.props,m=t.props,b=t.type;if("svg"===b&&(o=!0),null!=i){for(u=0;u<i.length;u++)if((f=i[u])&&"setAttribute"in f==!!b&&(b?f.localName===b:3===f.nodeType)){e=f,i[u]=null;break}}if(null==e){if(null===b)return document.createTextNode(m);e=o?document.createElementNS("http://www.w3.org/2000/svg",b):document.createElement(b,m.is&&m),i=null,s=!1}if(null===b)g===m||s&&e.data===m||(e.data=m);else{if(i=i&&H.call(e.childNodes),g=n.props||B,!s&&null!=i)for(g={},u=0;u<e.attributes.length;u++)g[(f=e.attributes[u]).name]=f.value;for(u in g)f=g[u],"children"==u||("dangerouslySetInnerHTML"==u?d=f:"key"===u||u in m||J(e,u,null,f,o));for(u in m)f=m[u],"children"==u?_=f:"dangerouslySetInnerHTML"==u?c=f:"value"==u?h=f:"checked"==u?p=f:"key"===u||s&&"function"!=typeof f||g[u]===f||J(e,u,f,g[u],o);if(c)s||d&&(c.__html===d.__html||c.__html===e.innerHTML)||(e.innerHTML=c.__html),t.__k=[];else if(d&&(e.innerHTML=""),K(e,U(_)?_:[_],t,n,r,o&&"foreignObject"!==b,i,a,i?i[0]:n.__k&&V(n,0),s,l),null!=i)for(u=i.length;u--;)null!=i[u]&&X(i[u]);s||(u="value",void 0===h||h===e[u]&&("progress"!==b||h)&&("option"!==b||h===g[u])||J(e,u,h,g[u],!1),u="checked",void 0!==p&&p!==e[u]&&J(e,u,p,g[u],!1))}return e}(n.__e,t,n,r,o,i,a,l,u);(c=T.diffed)&&c(t)}function er(e,t,n){for(var r=0;r<n.length;r++)eo(n[r],n[++r],n[++r]);T.__c&&T.__c(t,e),e.some(function(t){try{e=t.__h,t.__h=[],e.some(function(e){e.call(t)})}catch(e){T.__e(e,t.__v)}})}function eo(e,t,n){try{"function"==typeof e?e(t):e.current=t}catch(e){T.__e(e,n)}}function ei(e,t,n){var r,o;if(T.unmount&&T.unmount(e),(r=e.ref)&&(r.current&&r.current!==e.__e||eo(r,null,t)),null!=(r=e.__c)){if(r.componentWillUnmount)try{r.componentWillUnmount()}catch(e){T.__e(e,t)}r.base=r.__P=null,e.__c=void 0}if(r=e.__k)for(o=0;o<r.length;o++)r[o]&&ei(r[o],t,n||"function"!=typeof e.type);n||null==e.__e||X(e.__e),e.__=e.__e=e.__d=void 0}function ea(e,t,n){return this.constructor(e,n)}H=N.slice,T={__e:function(e,t,n,r){for(var o,i,a;t=t.__;)if((o=t.__c)&&!o.__)try{if((i=o.constructor)&&null!=i.getDerivedStateFromError&&(o.setState(i.getDerivedStateFromError(e)),a=o.__d),null!=o.componentDidCatch&&(o.componentDidCatch(e,r||{}),a=o.__d),a)return o.__E=o}catch(t){e=t}throw e}},R=0,q.prototype.setState=function(e,t){var n;n=null!=this.__s&&this.__s!==this.state?this.__s:this.__s=z({},this.state),"function"==typeof e&&(e=e(z({},n),this.props)),e&&z(n,e),null!=e&&this.__v&&(t&&this._sb.push(t),G(this))},q.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),G(this))},q.prototype.render=j,P=[],W="function"==typeof Promise?Promise.prototype.then.bind(Promise.resolve()):setTimeout,I=function(e,t){return e.__v.__b-t.__v.__b},Z.__r=0;var es,el,eu,ec,ed=0,e_=[],ef=[],eh=T,ep=eh.__b,eg=eh.__r,em=eh.diffed,eb=eh.__c,ev=eh.unmount,ey=eh.__;function ew(e,t){eh.__h&&eh.__h(el,e,ed||t),ed=0;var n=el.__H||(el.__H={__:[],__h:[]});return e>=n.__.length&&n.__.push({__V:ef}),n.__[e]}function ex(e){return ed=1,eC(eT,e)}function eC(e,t,n){var r=ew(es++,2);if(r.t=e,!r.__c&&(r.__=[n?n(t):eT(void 0,t),function(e){var t=r.__N?r.__N[0]:r.__[0],n=r.t(t,e);t!==n&&(r.__N=[n,r.__[1]],r.__c.setState({}))}],r.__c=el,!el.u)){var o=function(e,t,n){if(!r.__c.__H)return!0;var o=r.__c.__H.__.filter(function(e){return!!e.__c});if(o.every(function(e){return!e.__N}))return!i||i.call(this,e,t,n);var a=!1;return o.forEach(function(e){if(e.__N){var t=e.__[0];e.__=e.__N,e.__N=void 0,t!==e.__[0]&&(a=!0)}}),!(!a&&r.__c.props===e)&&(!i||i.call(this,e,t,n))};el.u=!0;var i=el.shouldComponentUpdate,a=el.componentWillUpdate;el.componentWillUpdate=function(e,t,n){if(this.__e){var r=i;i=void 0,o(e,t,n),i=r}a&&a.call(this,e,t,n)},el.shouldComponentUpdate=o}return r.__N||r.__}function ek(e,t){var n=ew(es++,4);!eh.__s&&eH(n.__H,t)&&(n.__=e,n.i=t,el.__h.push(n))}function eS(e,t){var n=ew(es++,7);return eH(n.__H,t)?(n.__V=e(),n.i=t,n.__h=e,n.__V):n.__}function eM(e,t){return ed=8,eS(function(){return e},t)}function eL(){for(var e;e=e_.shift();)if(e.__P&&e.__H)try{e.__H.__h.forEach(eD),e.__H.__h.forEach(eF),e.__H.__h=[]}catch(t){e.__H.__h=[],eh.__e(t,e.__v)}}eh.__b=function(e){el=null,ep&&ep(e)},eh.__=function(e,t){t.__k&&t.__k.__m&&(e.__m=t.__k.__m),ey&&ey(e,t)},eh.__r=function(e){eg&&eg(e),es=0;var t=(el=e.__c).__H;t&&(eu===el?(t.__h=[],el.__h=[],t.__.forEach(function(e){e.__N&&(e.__=e.__N),e.__V=ef,e.__N=e.i=void 0})):(t.__h.forEach(eD),t.__h.forEach(eF),t.__h=[],es=0)),eu=el},eh.diffed=function(e){em&&em(e);var t=e.__c;t&&t.__H&&(t.__H.__h.length&&(1!==e_.push(t)&&ec===eh.requestAnimationFrame||((ec=eh.requestAnimationFrame)||function(e){var t,n=function(){clearTimeout(r),eE&&cancelAnimationFrame(t),setTimeout(e)},r=setTimeout(n,100);eE&&(t=requestAnimationFrame(n))})(eL)),t.__H.__.forEach(function(e){e.i&&(e.__H=e.i),e.__V!==ef&&(e.__=e.__V),e.i=void 0,e.__V=ef})),eu=el=null},eh.__c=function(e,t){t.some(function(e){try{e.__h.forEach(eD),e.__h=e.__h.filter(function(e){return!e.__||eF(e)})}catch(n){t.some(function(e){e.__h&&(e.__h=[])}),t=[],eh.__e(n,e.__v)}}),eb&&eb(e,t)},eh.unmount=function(e){ev&&ev(e);var t,n=e.__c;n&&n.__H&&(n.__H.__.forEach(function(e){try{eD(e)}catch(e){t=e}}),n.__H=void 0,t&&eh.__e(t,n.__v))};var eE="function"==typeof requestAnimationFrame;function eD(e){var t=el,n=e.__c;"function"==typeof n&&(e.__c=void 0,n()),el=t}function eF(e){var t=el;e.__c=e.__(),el=t}function eH(e,t){return!e||e.length!==t.length||t.some(function(t,n){return t!==e[n]})}function eT(e,t){return"function"==typeof t?t(e):t}let eR=Object.defineProperty({__proto__:null,useCallback:eM,useContext:function(e){var t=el.context[e.__c],n=ew(es++,9);return n.c=e,t?(null==n.__&&(n.__=!0,t.sub(el)),t.props.value):e.__},useDebugValue:function(e,t){eh.useDebugValue&&eh.useDebugValue(t?t(e):e)},useEffect:function(e,t){var n=ew(es++,3);!eh.__s&&eH(n.__H,t)&&(n.__=e,n.i=t,el.__H.__h.push(n))},useErrorBoundary:function(e){var t=ew(es++,10),n=ex();return t.__=e,el.componentDidCatch||(el.componentDidCatch=function(e,r){t.__&&t.__(e,r),n[1](e)}),[n[0],function(){n[1](void 0)}]},useId:function(){var e=ew(es++,11);if(!e.__){for(var t=el.__v;null!==t&&!t.__m&&null!==t.__;)t=t.__;var n=t.__m||(t.__m=[0,0]);e.__="P"+n[0]+"-"+n[1]++}return e.__},useImperativeHandle:function(e,t,n){ed=6,ek(function(){return"function"==typeof e?(e(t()),function(){return e(null)}):e?(e.current=t(),function(){return e.current=null}):void 0},null==n?n:n.concat(e))},useLayoutEffect:ek,useMemo:eS,useReducer:eC,useRef:function(e){return ed=5,eS(function(){return{current:e}},[])},useState:ex},Symbol.toStringTag,{value:"Module"});function eP({options:e}){let t=eS(()=>({__html:function(){let e=e=>i.createElementNS("http://www.w3.org/2000/svg",e),t=S(e("svg"),{width:"32",height:"30",viewBox:"0 0 72 66",fill:"inherit"}),n=S(e("path"),{transform:"translate(11, 11)",d:"M29,2.26a4.67,4.67,0,0,0-8,0L14.42,13.53A32.21,32.21,0,0,1,32.17,40.19H27.55A27.68,27.68,0,0,0,12.09,17.47L6,28a15.92,15.92,0,0,1,9.23,12.17H4.62A.76.76,0,0,1,4,39.06l2.94-5a10.74,10.74,0,0,0-3.36-1.9l-2.91,5a4.54,4.54,0,0,0,1.69,6.24A4.66,4.66,0,0,0,4.62,44H19.15a19.4,19.4,0,0,0-8-17.31l2.31-4A23.87,23.87,0,0,1,23.76,44H36.07a35.88,35.88,0,0,0-16.41-31.8l4.67-8a.77.77,0,0,1,1.05-.27c.53.29,20.29,34.77,20.66,35.17a.76.76,0,0,1-.68,1.13H40.6q.09,1.91,0,3.81h4.78A4.59,4.59,0,0,0,50,39.43a4.49,4.49,0,0,0-.62-2.28Z"});return t.appendChild(n),t}().outerHTML}),[]);return Y("h2",{class:"dialog__header"},Y("span",{class:"dialog__title"},e.formTitle),e.showBranding?Y("a",{class:"brand-link",target:"_blank",href:"https://sentry.io/welcome/",title:"Powered by Sentry",rel:"noopener noreferrer",dangerouslySetInnerHTML:t}):null)}function eA(e,t){let n=e.get(t);return"string"==typeof n?n.trim():""}function eW({options:e,defaultEmail:t,defaultName:n,onFormClose:o,onSubmit:i,onSubmitSuccess:a,onSubmitError:s,showEmail:l,showName:u,screenshotInput:c}){let{tags:d,addScreenshotButtonLabel:_,removeScreenshotButtonLabel:f,cancelButtonLabel:h,emailLabel:p,emailPlaceholder:g,isEmailRequired:m,isNameRequired:b,messageLabel:v,messagePlaceholder:y,nameLabel:w,namePlaceholder:x,submitButtonLabel:k,isRequiredLabel:S}=e,[M,L]=ex(null),[E,D]=ex(!1),F=c?.input,[H,T]=ex(null),R=eM(e=>{T(e),D(!1)},[]),P=eM(e=>{let t=function(e,t){let n=[];return t.isNameRequired&&!e.name&&n.push(t.nameLabel),t.isEmailRequired&&!e.email&&n.push(t.emailLabel),e.message||n.push(t.messageLabel),n}(e,{emailLabel:p,isEmailRequired:m,isNameRequired:b,messageLabel:v,nameLabel:w});return t.length>0?L(`Please enter in the following required fields: ${t.join(", ")}`):L(null),0===t.length},[p,m,b,v,w]);return Y("form",{class:"form",onSubmit:eM(async e=>{try{if(e.preventDefault(),!(e.target instanceof HTMLFormElement))return;let t=new FormData(e.target),n=await (c&&E?c.value():void 0),o={name:eA(t,"name"),email:eA(t,"email"),message:eA(t,"message"),attachments:n?[n]:void 0};if(!P(o))return;try{await i({name:o.name,email:o.email,message:o.message,source:"widget",tags:d},{attachments:o.attachments}),a(o)}catch(e){C&&r.kgX.error(e),L(e),s(e)}}catch{}},[c&&E,a,s])},F&&E?Y(F,{onError:R}):null,Y("div",{class:"form__right","data-sentry-feedback":!0},Y("div",{class:"form__top"},M?Y("div",{class:"form__error-container"},M):null,u?Y("label",{for:"name",class:"form__label"},Y(eI,{label:w,isRequiredLabel:S,isRequired:b}),Y("input",{class:"form__input",defaultValue:n,id:"name",name:"name",placeholder:x,required:b,type:"text"})):Y("input",{"aria-hidden":!0,value:n,name:"name",type:"hidden"}),l?Y("label",{for:"email",class:"form__label"},Y(eI,{label:p,isRequiredLabel:S,isRequired:m}),Y("input",{class:"form__input",defaultValue:t,id:"email",name:"email",placeholder:g,required:m,type:"email"})):Y("input",{"aria-hidden":!0,value:t,name:"email",type:"hidden"}),Y("label",{for:"message",class:"form__label"},Y(eI,{label:v,isRequiredLabel:S,isRequired:!0}),Y("textarea",{autoFocus:!0,class:"form__input form__input--textarea",id:"message",name:"message",placeholder:y,required:!0,rows:5})),F?Y("label",{for:"screenshot",class:"form__label"},Y("button",{class:"btn btn--default",type:"button",onClick:()=>{T(null),D(e=>!e)}},E?f:_),H?Y("div",{class:"form__error-container"},H.message):null):null),Y("div",{class:"btn-group"},Y("button",{class:"btn btn--primary",type:"submit"},k),Y("button",{class:"btn btn--default",type:"button",onClick:o},h))))}function eI({label:e,isRequired:t,isRequiredLabel:n}){return Y("span",{class:"form__label__text"},e,t&&Y("span",{class:"form__label__text--required"},n))}function eB({open:e,onFormSubmitted:t,...n}){let r=n.options,i=eS(()=>({__html:function(){let e=e=>o.document.createElementNS("http://www.w3.org/2000/svg",e),t=S(e("svg"),{width:"16",height:"17",viewBox:"0 0 16 17",fill:"inherit"}),n=S(e("g"),{clipPath:"url(#clip0_57_156)"}),r=S(e("path"),{"fill-rule":"evenodd","clip-rule":"evenodd",d:"M3.55544 15.1518C4.87103 16.0308 6.41775 16.5 8 16.5C10.1217 16.5 12.1566 15.6571 13.6569 14.1569C15.1571 12.6566 16 10.6217 16 8.5C16 6.91775 15.5308 5.37103 14.6518 4.05544C13.7727 2.73985 12.5233 1.71447 11.0615 1.10897C9.59966 0.503466 7.99113 0.34504 6.43928 0.653721C4.88743 0.962403 3.46197 1.72433 2.34315 2.84315C1.22433 3.96197 0.462403 5.38743 0.153721 6.93928C-0.15496 8.49113 0.00346625 10.0997 0.608967 11.5615C1.21447 13.0233 2.23985 14.2727 3.55544 15.1518ZM4.40546 3.1204C5.46945 2.40946 6.72036 2.03 8 2.03C9.71595 2.03 11.3616 2.71166 12.575 3.92502C13.7883 5.13838 14.47 6.78405 14.47 8.5C14.47 9.77965 14.0905 11.0306 13.3796 12.0945C12.6687 13.1585 11.6582 13.9878 10.476 14.4775C9.29373 14.9672 7.99283 15.0953 6.73777 14.8457C5.48271 14.596 4.32987 13.9798 3.42502 13.075C2.52018 12.1701 1.90397 11.0173 1.65432 9.76224C1.40468 8.50718 1.5328 7.20628 2.0225 6.02404C2.5122 4.8418 3.34148 3.83133 4.40546 3.1204Z"}),i=S(e("path"),{d:"M6.68775 12.4297C6.78586 12.4745 6.89218 12.4984 7 12.5C7.11275 12.4955 7.22315 12.4664 7.32337 12.4145C7.4236 12.3627 7.51121 12.2894 7.58 12.2L12 5.63999C12.0848 5.47724 12.1071 5.28902 12.0625 5.11098C12.0178 4.93294 11.9095 4.77744 11.7579 4.67392C11.6064 4.57041 11.4221 4.52608 11.24 4.54931C11.0579 4.57254 10.8907 4.66173 10.77 4.79999L6.88 10.57L5.13 8.56999C5.06508 8.49566 4.98613 8.43488 4.89768 8.39111C4.80922 8.34735 4.713 8.32148 4.61453 8.31498C4.51605 8.30847 4.41727 8.32147 4.32382 8.35322C4.23038 8.38497 4.14413 8.43484 4.07 8.49999C3.92511 8.63217 3.83692 8.81523 3.82387 9.01092C3.81083 9.2066 3.87393 9.39976 4 9.54999L6.43 12.24C6.50187 12.3204 6.58964 12.385 6.68775 12.4297Z"});t.appendChild(n).append(i,r);let a=e("defs"),s=S(e("clipPath"),{id:"clip0_57_156"}),l=S(e("rect"),{width:"16",height:"16",fill:"white",transform:"translate(0 0.5)"});return s.appendChild(l),a.appendChild(s),t.appendChild(a).appendChild(s).appendChild(l),t}().outerHTML}),[]),[a,s]=ex(null),l=eM(()=>{a&&(clearTimeout(a),s(null)),t()},[a]),u=eM(e=>{n.onSubmitSuccess(e),s(setTimeout(()=>{t(),s(null)},5e3))},[t]);return Y(j,null,a?Y("div",{class:"success__position",onClick:l},Y("div",{class:"success__content"},r.successMessageText,Y("span",{class:"success__icon",dangerouslySetInnerHTML:i}))):Y("dialog",{class:"dialog",onClick:r.onFormClose,open:e},Y("div",{class:"dialog__position"},Y("div",{class:"dialog__content",onClick:e=>{e.stopPropagation()}},Y(eP,{options:r}),Y(eW,{...n,onSubmitSuccess:u})))))}let eN=`
.dialog {
  position: fixed;
  z-index: var(--z-index);
  margin: 0;
  inset: 0;

  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  height: 100vh;
  width: 100vw;

  color: var(--dialog-color, var(--foreground));
  fill: var(--dialog-color, var(--foreground));
  line-height: 1.75em;

  background-color: rgba(0, 0, 0, 0.05);
  border: none;
  inset: 0;
  opacity: 1;
  transition: opacity 0.2s ease-in-out;
}

.dialog__position {
  position: fixed;
  z-index: var(--z-index);
  inset: var(--dialog-inset);
  padding: var(--page-margin);
  display: flex;
  max-height: calc(100vh - (2 * var(--page-margin)));
}
@media (max-width: 600px) {
  .dialog__position {
    inset: var(--page-margin);
    padding: 0;
  }
}

.dialog__position:has(.editor) {
  inset: var(--page-margin);
  padding: 0;
}

.dialog:not([open]) {
  opacity: 0;
  pointer-events: none;
  visibility: hidden;
}
.dialog:not([open]) .dialog__content {
  transform: translate(0, -16px) scale(0.98);
}

.dialog__content {
  display: flex;
  flex-direction: column;
  gap: 16px;
  padding: var(--dialog-padding, 24px);
  max-width: 100%;
  width: 100%;
  max-height: 100%;
  overflow: auto;

  background: var(--dialog-background, var(--background));
  border-radius: var(--dialog-border-radius, 20px);
  border: var(--dialog-border, var(--border));
  box-shadow: var(--dialog-box-shadow, var(--box-shadow));
  transform: translate(0, 0) scale(1);
  transition: transform 0.2s ease-in-out;
}

`,eO=`
.dialog__header {
  display: flex;
  gap: 4px;
  justify-content: space-between;
  font-weight: var(--dialog-header-weight, 600);
  margin: 0;
}
.dialog__title {
  align-self: center;
  width: var(--form-width, 272px);
}

@media (max-width: 600px) {
  .dialog__title {
    width: auto;
  }
}

.dialog__position:has(.editor) .dialog__title {
  width: auto;
}


.brand-link {
  display: inline-flex;
}
.brand-link:focus-visible {
  outline: var(--outline);
}
`,eU=`
.form {
  display: flex;
  overflow: auto;
  flex-direction: row;
  gap: 16px;
  flex: 1 0;
}

.form__right {
  flex: 0 0 auto;
  display: flex;
  overflow: auto;
  flex-direction: column;
  justify-content: space-between;
  gap: 20px;
  width: var(--form-width, 100%);
}

.dialog__position:has(.editor) .form__right {
  width: var(--form-width, 272px);
}

.form__top {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.form__error-container {
  color: var(--error-color);
  fill: var(--error-color);
}

.form__label {
  display: flex;
  flex-direction: column;
  gap: 4px;
  margin: 0px;
}

.form__label__text {
  display: flex;
  gap: 4px;
  align-items: center;
}

.form__label__text--required {
  font-size: 0.85em;
}

.form__input {
  font-family: inherit;
  line-height: inherit;
  background: transparent;
  box-sizing: border-box;
  border: var(--input-border, var(--border));
  border-radius: var(--input-border-radius, 6px);
  color: var(--input-color, inherit);
  fill: var(--input-color, inherit);
  font-size: var(--input-font-size, inherit);
  font-weight: var(--input-font-weight, 500);
  padding: 6px 12px;
}

.form__input::placeholder {
  opacity: 0.65;
  color: var(--input-placeholder-color, inherit);
  filter: var(--interactive-filter);
}

.form__input:focus-visible {
  outline: var(--input-focus-outline, var(--outline));
}

.form__input--textarea {
  font-family: inherit;
  resize: vertical;
}

.error {
  color: var(--error-color);
  fill: var(--error-color);
}
`,ez=`
.btn-group {
  display: grid;
  gap: 8px;
}

.btn {
  line-height: inherit;
  border: var(--button-border, var(--border));
  border-radius: var(--button-border-radius, 6px);
  cursor: pointer;
  font-family: inherit;
  font-size: var(--button-font-size, inherit);
  font-weight: var(--button-font-weight, 600);
  padding: var(--button-padding, 6px 16px);
}
.btn[disabled] {
  opacity: 0.6;
  pointer-events: none;
}

.btn--primary {
  color: var(--button-primary-color, var(--accent-foreground));
  fill: var(--button-primary-color, var(--accent-foreground));
  background: var(--button-primary-background, var(--accent-background));
  border: var(--button-primary-border, var(--border));
  border-radius: var(--button-primary-border-radius, 6px);
  font-weight: var(--button-primary-font-weight, 500);
}
.btn--primary:hover {
  color: var(--button-primary-hover-color, var(--accent-foreground));
  fill: var(--button-primary-hover-color, var(--accent-foreground));
  background: var(--button-primary-hover-background, var(--accent-background));
  filter: var(--interactive-filter);
}
.btn--primary:focus-visible {
  background: var(--button-primary-hover-background, var(--accent-background));
  filter: var(--interactive-filter);
  outline: var(--button-primary-focus-outline, var(--outline));
}

.btn--default {
  color: var(--button-color, var(--foreground));
  fill: var(--button-color, var(--foreground));
  background: var(--button-background, var(--background));
  border: var(--button-border, var(--border));
  border-radius: var(--button-border-radius, 6px);
  font-weight: var(--button-font-weight, 500);
}
.btn--default:hover {
  color: var(--button-color, var(--foreground));
  fill: var(--button-color, var(--foreground));
  background: var(--button-hover-background, var(--background));
  filter: var(--interactive-filter);
}
.btn--default:focus-visible {
  background: var(--button-hover-background, var(--background));
  filter: var(--interactive-filter);
  outline: var(--button-focus-outline, var(--outline));
}
`,eX=`
.success__position {
  position: fixed;
  inset: var(--dialog-inset);
  padding: var(--page-margin);
  z-index: var(--z-index);
}
.success__content {
  background: var(--success-background, var(--background));
  border: var(--success-border, var(--border));
  border-radius: var(--success-border-radius, 1.7em/50%);
  box-shadow: var(--success-box-shadow, var(--box-shadow));
  font-weight: var(--success-font-weight, 600);
  color: var(--success-color);
  fill: var(--success-color);
  padding: 12px 24px;
  line-height: 1.75em;

  display: grid;
  align-items: center;
  grid-auto-flow: column;
  gap: 6px;
  cursor: default;
}

.success__icon {
  display: flex;
}
`,eY=()=>({name:"FeedbackModal",setupOnce(){},createDialog:({options:e,screenshotIntegration:t,sendFeedback:n,shadow:o})=>{let a=e.useSentryUser,s=function(){let e=(0,r.nZL)().getUser(),t=(0,r.aFn)().getUser(),n=(0,r.lWK)().getUser();return e&&Object.keys(e).length?e:t&&Object.keys(t).length?t:n}(),l=i.createElement("div"),u=function(e){let t=i.createElement("style");return t.textContent=`
:host {
  --dialog-inset: var(--inset);
}

${eN}
${eO}
${eU}
${ez}
${eX}
`,e&&t.setAttribute("nonce",e),t}(e.styleNonce),c="",d={get el(){return l},appendToDom(){o.contains(u)||o.contains(l)||(o.appendChild(u),o.appendChild(l))},removeFromDom(){o.removeChild(l),o.removeChild(u),i.body.style.overflow=c},open(){f(!0),e.onFormOpen?.(),r.s3S()?.emit("openFeedbackWidget"),c=i.body.style.overflow,i.body.style.overflow="hidden"},close(){f(!1),i.body.style.overflow=c}},_=t?.createInput({h:Y,hooks:eR,dialog:d,options:e}),f=t=>{var r,o,i,u;r=Y(eB,{options:e,screenshotInput:_,showName:e.showName||e.isNameRequired,showEmail:e.showEmail||e.isEmailRequired,defaultName:a&&s&&s[a.name]||"",defaultEmail:a&&s&&s[a.email]||"",onFormClose:()=>{f(!1),e.onFormClose?.()},onSubmit:n,onSubmitSuccess:t=>{f(!1),e.onSubmitSuccess?.(t)},onSubmitError:t=>{e.onSubmitError?.(t)},onFormSubmitted:()=>{e.onFormSubmitted?.()},open:t}),T.__&&T.__(r,l),o=l.__k,i=[],u=[],en(l,r=l.__k=Y(j,null,[r]),o||B,B,void 0!==l.ownerSVGElement,o?null:l.firstChild?H.call(l.childNodes):null,i,o?o.__e:l.firstChild,!1,u),r.__d=void 0,er(i,r,u)};return d}}),e$=o.devicePixelRatio,ej=e=>({x:Math.min(e.startX,e.endX),y:Math.min(e.startY,e.endY),width:Math.abs(e.startX-e.endX),height:Math.abs(e.startY-e.endY)}),eq=e=>{let t=e.clientHeight,n=e.clientWidth,r=e.width/e.height,o=t*r,i=t;return o>n&&(o=n,i=n/r),{x:(n-o)/2,y:(t-i)/2,width:o,height:i}},eV=o.devicePixelRatio,eG=e=>{let t=e.clientHeight,n=e.clientWidth,r=e.width/e.height,o=t*r,i=t;return o>n&&(o=n,i=n/r),{x:(n-o)/2,y:(t-i)/2,width:o,height:i}},eZ=()=>({name:"FeedbackScreenshot",setupOnce(){},createInput:({h:e,hooks:t,dialog:n,options:r})=>{let s=i.createElement("canvas");return{input:function({h:e,hooks:t,imageBuffer:n,dialog:r,options:s}){let l=function({hooks:e}){return function({onBeforeScreenshot:t,onScreenshot:n,onAfterScreenshot:r,onError:s}){e.useEffect(()=>{(async()=>{t();let e=await a.mediaDevices.getDisplayMedia({video:{width:o.innerWidth*o.devicePixelRatio,height:o.innerHeight*o.devicePixelRatio},audio:!1,monitorTypeSurfaces:"exclude",preferCurrentTab:!0,selfBrowserSurface:"include",surfaceSwitching:"exclude"}),s=i.createElement("video");await new Promise((t,r)=>{s.srcObject=e,s.onloadedmetadata=()=>{n(s),e.getTracks().forEach(e=>e.stop()),t()},s.play().catch(r)}),r()})().catch(s)},[])}}({hooks:t}),u=function({h:e}){return function({action:t,setAction:n}){let r=function({h:e}){return function(){return e("svg",{width:"20",height:"20",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e("path",{d:"M8.5 12L12 8.5L14 11L11 14L8.5 12Z",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"}),e("path",{d:"M12 8.5L11 3.5L2 2L3.5 11L8.5 12L12 8.5Z",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"}),e("path",{d:"M2 2L7.5 7.5",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"}))}}({h:e}),o=function({h:e}){return function(){return e("svg",{width:"20",height:"20",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e("path",{d:"M15.25 12.5H12.5M12.5 12.5H4.50001C3.94773 12.5 3.50001 12.0523 3.50001 11.5V3.50002M12.5 12.5L12.5 4.50002C12.5 3.94773 12.0523 3.50002 11.5 3.50002H3.50001M12.5 12.5L12.5 15.25M3.50001 3.50002V0.750031M3.50001 3.50002H0.75",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"}))}}({h:e});return e("div",{class:"editor__tool-container"},e("div",null),e("div",{class:"editor__tool-bar"},e("button",{type:"button",class:`editor__tool ${"crop"===t?"editor__tool--active":""}`,onClick:()=>{"crop"===t?n(""):n("crop")}},e(o,null)),e("button",{type:"button",class:`editor__tool ${"annotate"===t?"editor__tool--active":""}`,onClick:()=>{"annotate"===t?n(""):n("annotate")}},e(r,null))),e("div",null))}}({h:e}),c=function({h:e}){return function({action:t,imageBuffer:n,annotatingRef:r}){let o=()=>{let e=n.getContext("2d"),t=r.current;if(e&&t){e.drawImage(t,0,0,t.width,t.height,0,0,n.width,n.height);let r=t.getContext("2d");r&&r.clearRect(0,0,t.width,t.height)}};return e("canvas",{class:`editor__annotation ${"annotate"===t?"editor__annotation--active":""}`,onMouseDown:()=>{if("annotate"!==t)return;let e=e=>{let t=r.current;if(t){let n=t.getBoundingClientRect(),r=e.clientX-n.x,o=e.clientY-n.y,i=t.getContext("2d");i&&(i.lineTo(r,o),i.stroke(),i.beginPath(),i.moveTo(r,o))}},n=()=>{let t=r.current?.getContext("2d");t&&t.beginPath(),o(),i.removeEventListener("mousemove",e),i.removeEventListener("mouseup",n)};i.addEventListener("mousemove",e),i.addEventListener("mouseup",n)},ref:r})}}({h:e}),d=function({h:e,hooks:t,options:n}){let r=function({h:e}){return function({top:t,left:n,corner:r,onGrabButton:o}){return e("button",{class:`editor__crop-corner editor__crop-corner--${r} `,style:{top:t,left:n},onMouseDown:e=>{e.preventDefault(),o(e,r)},onClick:e=>{e.preventDefault()}})}}({h:e});return function({action:o,imageBuffer:a,croppingRef:s,cropContainerRef:l,croppingRect:u,setCroppingRect:c,resize:d}){let _=t.useRef({initialX:0,initialY:0}),[f,h]=t.useState(!1),[p,g]=t.useState(!1);t.useEffect(()=>{let e=s.current;if(!e)return;let t=e.getContext("2d");if(!t)return;let n=eq(a),r=ej(u);t.clearRect(0,0,n.width,n.height),"crop"===o&&(t.fillStyle="rgba(0, 0, 0, 0.5)",t.fillRect(0,0,n.width,n.height),t.clearRect(r.x,r.y,r.width,r.height),t.strokeStyle="#ffffff",t.lineWidth=3,t.strokeRect(r.x+1,r.y+1,r.width-2,r.height-2),t.strokeStyle="#000000",t.lineWidth=1,t.strokeRect(r.x+3,r.y+3,r.width-6,r.height-6))},[u,o]);let m=t.useCallback(e=>t=>{if(!s.current)return;let n=s.current,r=n.getBoundingClientRect(),o=t.clientX-r.x,i=t.clientY-r.y;switch(e){case"top-left":c(e=>({...e,startX:Math.min(Math.max(0,o),e.endX-33),startY:Math.min(Math.max(0,i),e.endY-33)}));break;case"top-right":c(e=>({...e,endX:Math.max(Math.min(o,n.width/e$),e.startX+33),startY:Math.min(Math.max(0,i),e.endY-33)}));break;case"bottom-left":c(e=>({...e,startX:Math.min(Math.max(0,o),e.endX-33),endY:Math.max(Math.min(i,n.height/e$),e.startY+33)}));break;case"bottom-right":c(e=>({...e,endX:Math.max(Math.min(o,n.width/e$),e.startX+33),endY:Math.max(Math.min(i,n.height/e$),e.startY+33)}))}},[]),b=(e,t)=>{h(!0);let n=m(t),r=()=>{i.removeEventListener("mousemove",n),i.removeEventListener("mouseup",r),g(!0),h(!1)};i.addEventListener("mouseup",r),i.addEventListener("mousemove",n)};return e("div",{class:`editor__crop-container ${"crop"===o?"":"editor__crop-container--inactive"}
              ${p?"editor__crop-container--move":""}`,ref:l},e("canvas",{onMouseDown:e=>{if(f)return;_.current={initialX:e.clientX,initialY:e.clientY};let t=e=>{let t=s.current;if(!t)return;let n=e.clientX-_.current.initialX,r=e.clientY-_.current.initialY;c(o=>{let i=Math.max(0,Math.min(o.startX+n,t.width/e$-(o.endX-o.startX))),a=Math.max(0,Math.min(o.startY+r,t.height/e$-(o.endY-o.startY))),s=i+(o.endX-o.startX),l=a+(o.endY-o.startY);return _.current.initialX=e.clientX,_.current.initialY=e.clientY,{startX:i,startY:a,endX:s,endY:l}})},n=()=>{i.removeEventListener("mousemove",t),i.removeEventListener("mouseup",n)};i.addEventListener("mousemove",t),i.addEventListener("mouseup",n)},ref:s}),"crop"===o&&e("div",null,e(r,{left:u.startX-3,top:u.startY-3,onGrabButton:b,corner:"top-left"}),e(r,{left:u.endX-30+3,top:u.startY-3,onGrabButton:b,corner:"top-right"}),e(r,{left:u.startX-3,top:u.endY-30+3,onGrabButton:b,corner:"bottom-left"}),e(r,{left:u.endX-30+3,top:u.endY-30+3,onGrabButton:b,corner:"bottom-right"})),"crop"===o&&e("div",{style:{left:Math.max(0,u.endX-191),top:Math.max(0,u.endY+8)},class:`editor__crop-btn-group ${p?"editor__crop-btn-group--active":""}`},e("button",{onClick:e=>{e.preventDefault(),s.current&&c({startX:0,startY:0,endX:s.current.width/e$,endY:s.current.height/e$}),g(!1)},class:"btn btn--default"},n.cancelButtonLabel),e("button",{onClick:e=>{e.preventDefault(),function(){let e=i.createElement("canvas"),t=eq(a),n=ej(u);e.width=n.width*e$,e.height=n.height*e$;let r=e.getContext("2d");r&&a&&r.drawImage(a,n.x/t.width*a.width,n.y/t.height*a.height,n.width/t.width*a.width,n.height/t.height*a.height,0,0,e.width,e.height);let o=a.getContext("2d");o&&(o.clearRect(0,0,a.width,a.height),a.width=e.width,a.height=e.height,a.style.width=`${n.width}px`,a.style.height=`${n.height}px`,o.drawImage(e,0,0),d())}(),g(!1)},class:"btn btn--primary"},n.confirmButtonLabel)))}}({h:e,hooks:t,options:s});return function({onError:a}){let _=t.useMemo(()=>({__html:function(e){let t=i.createElement("style"),n="#1A141F",r="#302735";return t.textContent=`
.editor {
  display: flex;
  flex-grow: 1;
  flex-direction: column;
}
.editor__image-container {
  padding: 10px;
  padding-top: 65px;
  padding-bottom: 65px;
  position: relative;
  height: 100%;
  border-radius: var(--menu-border-radius, 6px);

  background-color: ${n};
  background-image: repeating-linear-gradient(
      -145deg,
      transparent,
      transparent 8px,
      ${n} 8px,
      ${n} 11px
    ),
    repeating-linear-gradient(
      -45deg,
      transparent,
      transparent 15px,
      ${r} 15px,
      ${r} 16px
    );
}

.editor__annotation {
  z-index: 1;
}
.editor__annotation--active {
  z-index: 2;
}

.editor__canvas-container {
  width: 100%;
  height: 100%;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}

.editor__canvas-container canvas {
  object-fit: contain;
  position: absolute;
}

.editor__crop-container {
  custor: auto;
  position: absolute;
  z-index: 2;
}
.editor__crop-container--inactive {
  z-index: 1;
}
.editor__crop-container--move {
  cursor: move;
}

.editor__crop-btn-group {
  padding: 8px;
  gap: 8px;
  border-radius: var(--menu-border-radius, 6px);
  background: var(--button-background, var(--background));
  width: 175px;
  position: absolute;
  display: none;
}
.editor__crop-btn-group--active {
  display: flex;
}

.editor__crop-corner {
  width: 30px;
  height: 30px;
  position: absolute;
  background: none;
  border: 3px solid #ffffff;
}

.editor__crop-corner--top-left {
  cursor: nwse-resize;
  border-right: none;
  border-bottom: none;
}
.editor__crop-corner--top-right {
  cursor: nesw-resize;
  border-left: none;
  border-bottom: none;
}
.editor__crop-corner--bottom-left {
  cursor: nesw-resize;
  border-right: none;
  border-top: none;
}
.editor__crop-corner--bottom-right {
  cursor: nwse-resize;
  border-left: none;
  border-top: none;
}
.editor__tool-container {
  padding-top: 8px;
  display: flex;
  justify-content: space-between;
}
.editor__tool-bar {
  display: flex;
  gap: 8px;
}
.editor__tool {
  display: flex;
  padding: 8px 12px;
  justify-content: center;
  align-items: center;
  border: var(--button-border, var(--border));
  border-radius: var(--button-border-radius, 6px);
  background: var(--button-background, var(--background));
  color: var(--button-foreground, var(--foreground));
}

.editor__tool--active {
  background: var(--button-primary-background, var(--accent-background));
  color: var(--button-primary-foreground, var(--accent-foreground));
}
`,e&&t.setAttribute("nonce",e),t}(s.styleNonce).innerText}),[]),f=t.useRef(null),h=t.useRef(null),p=t.useRef(null),g=t.useRef(null),[m,b]=t.useState("crop"),[v,y]=t.useState({startX:0,startY:0,endX:0,endY:0});function w(e,t){let n=e.current;if(!n)return;n.width=t.width*eV,n.height=t.height*eV,n.style.width=`${t.width}px`,n.style.height=`${t.height}px`;let r=n.getContext("2d");r&&r.scale(eV,eV)}function x(){let e=eG(n);w(g,e),w(p,e);let t=h.current;t&&(t.style.width=`${e.width}px`,t.style.height=`${e.height}px`),y({startX:0,startY:0,endX:e.width,endY:e.height})}return t.useEffect(()=>(o.addEventListener("resize",x),()=>{o.removeEventListener("resize",x)}),[]),l({onBeforeScreenshot:t.useCallback(()=>{r.el.style.display="none"},[]),onScreenshot:t.useCallback(e=>{let t=n.getContext("2d");if(!t)throw Error("Could not get canvas context");n.width=e.videoWidth,n.height=e.videoHeight,n.style.width="100%",n.style.height="100%",t.drawImage(e,0,0)},[n]),onAfterScreenshot:t.useCallback(()=>{r.el.style.display="block";let e=f.current;e?.appendChild(n),x()},[]),onError:t.useCallback(e=>{r.el.style.display="block",a(e)},[])}),e("div",{class:"editor"},e("style",{nonce:s.styleNonce,dangerouslySetInnerHTML:_}),e("div",{class:"editor__image-container"},e("div",{class:"editor__canvas-container",ref:f},e(d,{action:m,imageBuffer:n,croppingRef:g,cropContainerRef:h,croppingRect:v,setCroppingRect:y,resize:x}),e(c,{action:m,imageBuffer:n,annotatingRef:p}))),s._experiments.annotations&&e(u,{action:m,setAction:b}))}}({h:e,hooks:t,imageBuffer:s,dialog:n,options:r}),value:async()=>{let e=await new Promise(e=>{s.toBlob(e,"image/png")});if(e)return{data:new Uint8Array(await e.arrayBuffer()),filename:"screenshot.png",contentType:"application/png"}}}}})},15060:function(e,t,n){let r;var o,i,a,s=n(33975);function l(e,t,n=1/0,r=0){return!e||e.nodeType!==e.ELEMENT_NODE||r>n?-1:t(e)?r:l(e.parentNode,t,n,r+1)}function u(e,t){return n=>{if(null===n)return!1;try{if(e){if("string"==typeof e){if(n.matches(`.${e}`))return!0}else if(function(e,t){for(let n=e.classList.length;n--;){let r=e.classList[n];if(t.test(r))return!0}return!1}(n,e))return!0}if(t&&n.matches(t))return!0;return!1}catch{return!1}}}(o=a||(a={}))[o.Document=0]="Document",o[o.DocumentType=1]="DocumentType",o[o.Element=2]="Element",o[o.Text=3]="Text",o[o.CDATA=4]="CDATA",o[o.Comment=5]="Comment";let c="Please stop import mirror directly. Instead of that,\r\nnow you can use replayer.getMirror() to access the mirror instance of a replayer,\r\nor you can use record.mirror to access the mirror instance during recording.",d={map:{},getId:()=>(console.error(c),-1),getNode:()=>(console.error(c),null),removeNodeFromMap(){console.error(c)},has:()=>(console.error(c),!1),reset(){console.error(c)}};function _(e,t,n,r,o=window){let i=o.Object.getOwnPropertyDescriptor(e,t);return o.Object.defineProperty(e,t,r?n:{set(e){b(()=>{n.set.call(this,e)},0),i&&i.set&&i.set.call(this,e)}}),()=>_(e,t,i||{},!0)}function f(e,t,n){try{if(!(t in e))return()=>{};let r=e[t],o=n(r);return"function"==typeof o&&(o.prototype=o.prototype||{},Object.defineProperties(o,{__rrweb_original__:{enumerable:!1,value:r}})),e[t]=o,()=>{e[t]=r}}catch{return()=>{}}}function h(e,t,n,r,o){if(!e)return!1;let i=e?e.nodeType===e.ELEMENT_NODE?e:e.parentElement:null;if(!i)return!1;let a=l(i,u(t,n)),s=-1;return!(a<0)&&(r&&(s=l(i,u(null,r))),a>-1&&s<0||a<s)}"undefined"!=typeof window&&window.Proxy&&window.Reflect&&(d=new Proxy(d,{get:(e,t,n)=>("map"===t&&console.error(c),Reflect.get(e,t,n))})),/[1-9][0-9]{12}/.test(Date.now().toString());let p={};function g(e){let t=p[e];if(t)return t;let n=window.document,r=window[e];if(n&&"function"==typeof n.createElement)try{let t=n.createElement("iframe");t.hidden=!0,n.head.appendChild(t);let o=t.contentWindow;o&&o[e]&&(r=o[e]),n.head.removeChild(t)}catch(e){}return p[e]=r.bind(window)}function m(...e){return g("requestAnimationFrame")(...e)}function b(...e){return g("setTimeout")(...e)}var v=((i=v||{})[i["2D"]=0]="2D",i[i.WebGL=1]="WebGL",i[i.WebGL2=2]="WebGL2",i);let y=e=>r?(...t)=>{try{return e(...t)}catch(e){if(r&&!0===r(e))return()=>{};throw e}}:e;for(var w="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",x="undefined"==typeof Uint8Array?[]:new Uint8Array(256),C=0;C<w.length;C++)x[w.charCodeAt(C)]=C;var k=function(e){var t,n=new Uint8Array(e),r=n.length,o="";for(t=0;t<r;t+=3)o+=w[n[t]>>2]+w[(3&n[t])<<4|n[t+1]>>4]+w[(15&n[t+1])<<2|n[t+2]>>6]+w[63&n[t+2]];return r%3==2?o=o.substring(0,o.length-1)+"=":r%3==1&&(o=o.substring(0,o.length-2)+"=="),o};let S=new Map,M=(e,t,n)=>{let r;if(!e||!(E(e,t)||"object"==typeof e))return;let o=e.constructor.name,i=((r=S.get(n))||(r=new Map,S.set(n,r)),r.has(o)||r.set(o,[]),r.get(o)),a=i.indexOf(e);return -1===a&&(a=i.length,i.push(e)),a},L=(e,t,n)=>e.map(e=>(function e(t,n,r){if(t instanceof Array)return t.map(t=>e(t,n,r));if(null===t);else if(t instanceof Float32Array||t instanceof Float64Array||t instanceof Int32Array||t instanceof Uint32Array||t instanceof Uint8Array||t instanceof Uint16Array||t instanceof Int16Array||t instanceof Int8Array||t instanceof Uint8ClampedArray)return{rr_type:t.constructor.name,args:[Object.values(t)]};else if(t instanceof ArrayBuffer)return{rr_type:t.constructor.name,base64:k(t)};else if(t instanceof DataView)return{rr_type:t.constructor.name,args:[e(t.buffer,n,r),t.byteOffset,t.byteLength]};else if(t instanceof HTMLImageElement){let e=t.constructor.name,{src:n}=t;return{rr_type:e,src:n}}else if(t instanceof HTMLCanvasElement)return{rr_type:"HTMLImageElement",src:t.toDataURL()};else if(t instanceof ImageData)return{rr_type:t.constructor.name,args:[e(t.data,n,r),t.width,t.height]};else if(E(t,n)||"object"==typeof t)return{rr_type:t.constructor.name,index:M(t,n,r)};return t})(e,t,n)),E=(e,t)=>!!["WebGLActiveInfo","WebGLBuffer","WebGLFramebuffer","WebGLProgram","WebGLRenderbuffer","WebGLShader","WebGLShaderPrecisionFormat","WebGLTexture","WebGLUniformLocation","WebGLVertexArrayObject","WebGLVertexArrayObjectOES"].filter(e=>"function"==typeof t[e]).find(n=>e instanceof t[n]);function D(e,t,n,r,o){let i=[];try{let a=f(e.HTMLCanvasElement.prototype,"getContext",function(e){return function(i,...a){if(!h(this,t,n,r,!0)){let e="experimental-webgl"===i?"webgl":i;if("__context"in this||(this.__context=e),o&&["webgl","webgl2"].includes(e)){if(a[0]&&"object"==typeof a[0]){let e=a[0];e.preserveDrawingBuffer||(e.preserveDrawingBuffer=!0)}else a.splice(0,1,{preserveDrawingBuffer:!0})}}return e.apply(this,[i,...a])}});i.push(a)}catch{console.error("failed to patch HTMLCanvasElement.prototype.getContext")}return()=>{i.forEach(e=>e())}}function F(e,t,n,r,o,i,a,s){let l=[];for(let a of Object.getOwnPropertyNames(e))if(!["isContextLost","canvas","drawingBufferWidth","drawingBufferHeight"].includes(a))try{if("function"!=typeof e[a])continue;let u=f(e,a,function(e){return function(...l){let u=e.apply(this,l);if(M(u,s,this),"tagName"in this.canvas&&!h(this.canvas,r,o,i,!0)){let e=L(l,s,this),r={type:t,property:a,args:e};n(this.canvas,r)}return u}});l.push(u)}catch{let r=_(e,a,{set(e){n(this.canvas,{type:t,property:a,args:[e],setter:!0})}});l.push(r)}return l}class H{reset(){this.pendingCanvasMutations.clear(),this.restoreHandlers.forEach(e=>{try{e()}catch(e){}}),this.restoreHandlers=[],this.windowsSet=new WeakSet,this.windows=[],this.shadowDoms=new Set,this.worker?.terminate(),this.worker=null,this.snapshotInProgressMap=new Map}freeze(){this.frozen=!0}unfreeze(){this.frozen=!1}lock(){this.locked=!0}unlock(){this.locked=!1}constructor(e){this.pendingCanvasMutations=new Map,this.rafStamps={latestId:0,invokeId:null},this.shadowDoms=new Set,this.windowsSet=new WeakSet,this.windows=[],this.restoreHandlers=[],this.frozen=!1,this.locked=!1,this.snapshotInProgressMap=new Map,this.worker=null,this.processMutation=(e,t)=>{(this.rafStamps.invokeId&&this.rafStamps.latestId!==this.rafStamps.invokeId||!this.rafStamps.invokeId)&&(this.rafStamps.invokeId=this.rafStamps.latestId),this.pendingCanvasMutations.has(e)||this.pendingCanvasMutations.set(e,[]),this.pendingCanvasMutations.get(e).push(t)};let{sampling:t="all",win:n,blockClass:o,blockSelector:i,unblockSelector:a,maxCanvasSize:s,recordCanvas:l,dataURLOptions:u,errorHandler:c}=e;if(this.mutationCb=e.mutationCb,this.mirror=e.mirror,this.options=e,c&&(r=c),(l&&"number"==typeof t||e.enableManualSnapshot)&&(this.worker=this.initFPSWorker()),this.addWindow(n),e.enableManualSnapshot)return;y(()=>{l&&"all"===t&&(this.startRAFTimestamping(),this.startPendingCanvasMutationFlusher()),l&&"number"==typeof t&&this.initCanvasFPSObserver(t,o,i,a,s,{dataURLOptions:u})})()}addWindow(e){let{sampling:t="all",blockClass:n,blockSelector:r,unblockSelector:o,recordCanvas:i,enableManualSnapshot:a}=this.options;if(!this.windowsSet.has(e)){if(a){this.windowsSet.add(e),this.windows.push(new WeakRef(e));return}y(()=>{if(i&&"all"===t&&this.initCanvasMutationObserver(e,n,r,o),i&&"number"==typeof t){let t=D(e,n,r,o,!0);this.restoreHandlers.push(()=>{t()})}})(),this.windowsSet.add(e),this.windows.push(new WeakRef(e))}}addShadowRoot(e){this.shadowDoms.add(new WeakRef(e))}resetShadowRoots(){this.shadowDoms=new Set}initFPSWorker(){let e=new Worker(function(){let e=new Blob(['for(var e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",t="undefined"==typeof Uint8Array?[]:new Uint8Array(256),a=0;a<64;a++)t[e.charCodeAt(a)]=a;var n=function(t){var a,n=new Uint8Array(t),r=n.length,s="";for(a=0;a<r;a+=3)s+=e[n[a]>>2],s+=e[(3&n[a])<<4|n[a+1]>>4],s+=e[(15&n[a+1])<<2|n[a+2]>>6],s+=e[63&n[a+2]];return r%3==2?s=s.substring(0,s.length-1)+"=":r%3==1&&(s=s.substring(0,s.length-2)+"=="),s};const r=new Map,s=new Map;const i=self;i.onmessage=async function(e){if(!("OffscreenCanvas"in globalThis))return i.postMessage({id:e.data.id});{const{id:t,bitmap:a,width:o,height:f,maxCanvasSize:c,dataURLOptions:g}=e.data,u=async function(e,t,a){const r=e+"-"+t;if("OffscreenCanvas"in globalThis){if(s.has(r))return s.get(r);const i=new OffscreenCanvas(e,t);i.getContext("2d");const o=await i.convertToBlob(a),f=await o.arrayBuffer(),c=n(f);return s.set(r,c),c}return""}(o,f,g),[h,d]=function(e,t,a){if(!a)return[e,t];const[n,r]=a;if(e<=n&&t<=r)return[e,t];let s=e,i=t;return s>n&&(i=Math.floor(n*t/e),s=n),i>r&&(s=Math.floor(r*e/t),i=r),[s,i]}(o,f,c),l=new OffscreenCanvas(h,d),w=l.getContext("bitmaprenderer"),p=h===o&&d===f?a:await createImageBitmap(a,{resizeWidth:h,resizeHeight:d,resizeQuality:"low"});w.transferFromImageBitmap(p),a.close();const y=await l.convertToBlob(g),v=y.type,b=await y.arrayBuffer(),m=n(b);if(p.close(),!r.has(t)&&await u===m)return r.set(t,m),i.postMessage({id:t});if(r.get(t)===m)return i.postMessage({id:t});i.postMessage({id:t,type:v,base64:m,width:o,height:f}),r.set(t,m)}};']);return URL.createObjectURL(e)}());return e.onmessage=e=>{let t=e.data,{id:n}=t;if(this.snapshotInProgressMap.set(n,!1),!("base64"in t))return;let{base64:r,type:o,width:i,height:a}=t;this.mutationCb({id:n,type:v["2D"],commands:[{property:"clearRect",args:[0,0,i,a]},{property:"drawImage",args:[{rr_type:"ImageBitmap",args:[{rr_type:"Blob",data:[{rr_type:"ArrayBuffer",base64:r}],type:o}]},0,0,i,a]}]})},e}initCanvasFPSObserver(e,t,n,r,o,i){let a=this.takeSnapshot(!1,e,t,n,r,o,i.dataURLOptions);this.restoreHandlers.push(()=>{cancelAnimationFrame(a)})}initCanvasMutationObserver(e,t,n,r){let o=D(e,t,n,r,!1),i=function(e,t,n,r,o){let i=[];for(let a of Object.getOwnPropertyNames(t.CanvasRenderingContext2D.prototype))try{if("function"!=typeof t.CanvasRenderingContext2D.prototype[a])continue;let s=f(t.CanvasRenderingContext2D.prototype,a,function(i){return function(...s){return h(this.canvas,n,r,o,!0)||b(()=>{let n=L(s,t,this);e(this.canvas,{type:v["2D"],property:a,args:n})},0),i.apply(this,s)}});i.push(s)}catch{let n=_(t.CanvasRenderingContext2D.prototype,a,{set(t){e(this.canvas,{type:v["2D"],property:a,args:[t],setter:!0})}});i.push(n)}return()=>{i.forEach(e=>e())}}(this.processMutation.bind(this),e,t,n,r),a=function(e,t,n,r,o,i){let a=[];return a.push(...F(t.WebGLRenderingContext.prototype,v.WebGL,e,n,r,o,i,t)),void 0!==t.WebGL2RenderingContext&&a.push(...F(t.WebGL2RenderingContext.prototype,v.WebGL2,e,n,r,o,i,t)),()=>{a.forEach(e=>e())}}(this.processMutation.bind(this),e,t,n,r,this.mirror);this.restoreHandlers.push(()=>{o(),i(),a()})}snapshot(e){let{options:t}=this,n=this.takeSnapshot(!0,"all"===t.sampling?2:t.sampling||2,t.blockClass,t.blockSelector,t.unblockSelector,t.maxCanvasSize,t.dataURLOptions,e);this.restoreHandlers.push(()=>{cancelAnimationFrame(n)})}takeSnapshot(e,t,n,r,o,i,a,s){let l=1e3/t,u=0,c=e=>{if(e)return[e];let t=[],i=e=>{e.querySelectorAll("canvas").forEach(e=>{h(e,n,r,o)||t.push(e)})};for(let e of this.windows){let t=e.deref();t&&i(t.document)}for(let e of this.shadowDoms){let t=e.deref();t&&i(t)}return t},d=t=>{if(this.windows.length){if(u&&t-u<l){m(d);return}u=t,c(s).forEach(t=>{if(!this.mirror.hasNode(t))return;let n=this.mirror.getId(t);if(!this.snapshotInProgressMap.get(n)&&t.width&&t.height){if(this.snapshotInProgressMap.set(n,!0),!e&&["webgl","webgl2"].includes(t.__context)){let e=t.getContext(t.__context);e?.getContextAttributes()?.preserveDrawingBuffer===!1&&e.clear(e.COLOR_BUFFER_BIT)}createImageBitmap(t).then(e=>{this.worker?.postMessage({id:n,bitmap:e,width:t.width,height:t.height,dataURLOptions:a,maxCanvasSize:i},[e])}).catch(e=>{y(()=>{throw e})()})}}),e||m(d)}};return m(d)}startPendingCanvasMutationFlusher(){m(()=>this.flushPendingCanvasMutations())}startRAFTimestamping(){let e=t=>{this.rafStamps.latestId=t,m(e)};m(e)}flushPendingCanvasMutations(){this.pendingCanvasMutations.forEach((e,t)=>{let n=this.mirror.getId(t);this.flushPendingCanvasMutationFor(t,n)}),m(()=>this.flushPendingCanvasMutations())}flushPendingCanvasMutationFor(e,t){if(this.frozen||this.locked)return;let n=this.pendingCanvasMutations.get(e);if(!n||-1===t)return;let r=n.map(e=>{let{type:t,...n}=e;return n}),{type:o}=n[0];this.mutationCb({id:t,type:o,commands:r}),this.pendingCanvasMutations.delete(e)}}let T={low:{sampling:{canvas:1},dataURLOptions:{type:"image/webp",quality:.25}},medium:{sampling:{canvas:2},dataURLOptions:{type:"image/webp",quality:.4}},high:{sampling:{canvas:4},dataURLOptions:{type:"image/webp",quality:.5}}};(0,s._Id)((e={})=>{let t;let[n,r]=e.maxCanvasSize||[],o={quality:e.quality||"medium",enableManualSnapshot:e.enableManualSnapshot,maxCanvasSize:[n?Math.min(n,1280):1280,r?Math.min(r,1280):1280]},i=new Promise(e=>t=e);return{name:"ReplayCanvas",getOptions(){let{quality:e,enableManualSnapshot:n,maxCanvasSize:r}=o;return{enableManualSnapshot:n,recordCanvas:!0,getCanvasManager:e=>{let o=new H({...e,enableManualSnapshot:n,maxCanvasSize:r,errorHandler:e=>{try{"object"==typeof e&&(e.__rrweb__=!0)}catch(e){}}});return t(o),o},...T[e||"medium"]||T.medium}},async snapshot(e){(await i).snapshot(e)}}})}}]);